package page_objects;

import com.google.gson.JsonObject;
import data.SQLiteManager;
import org.openqa.selenium.*;

import java.sql.Connection;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UtilMethods {


    private static By by_title_text(String text) {
        return By.xpath("//h3[text()='" + text + "']");
    }




    /**
     * Switch window to new window tab
     * @return the string of original tab
     */
    public static void switchTab(WebDriver driver, boolean switchOriginalTab) {
        try {
            if(switchOriginalTab) {
                Set<String> allTabs = driver.getWindowHandles();
                Iterator<String> iterator = allTabs.iterator();
                if (iterator.hasNext()) {
                    String firstTab = iterator.next();
                    driver.switchTo().window(firstTab);
                    while (iterator.hasNext()) {
                        String otherTab = iterator.next();
                        driver.switchTo().window(otherTab);
                        driver.close();
                    }
                    driver.switchTo().window(firstTab);
                }
            }else{
                Set<String> allTabs = driver.getWindowHandles();
                String originalTab = driver.getWindowHandle();
                for (String tab : allTabs) {
                    if (!tab.equals(originalTab)) {
                        driver.switchTo().window(tab);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Switch window to original window tab
     */
    public void switchOriginalTab(WebDriver driver) {
        try {
            Set<String> allTabs = driver.getWindowHandles();
            String originalTab = driver.getWindowHandle();
            driver.switchTo().window(originalTab);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Evaluate if the title is present
     * @param driver driver
     * @param titleToValidate text to validate
     * @return
     */
    public static boolean getTitlePresent(WebDriver driver,String titleToValidate) {
        try {
            return !driver.findElements(by_title_text(titleToValidate)).isEmpty();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Scroll forward the object to be search
     * @param driver driver
     * @param element web element
     */
    public static boolean scrollToElement(WebDriver driver, WebElement element) {
        try {
            JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
            jsExecutor.executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", element);
            return true;
        } catch (Exception e) {
            System.err.println("Error al hacer scroll hasta el elemento: " + e.getMessage());
            return false;
        }
    }

    /**
     * Extracts structured bibliographic information from an HTML blockquote element
     * using Selenium WebDriver and stores it in a JsonObject from Gson library.
     * @param blockquote WebDriver instance used to navigate the web page.
     * @return A JsonObject containing structured data extracted from the blockquote.
     */
    public static JsonObject extractArticleData(WebElement blockquote, Connection connection,int autorID,String autorFullName) {
        JsonObject bibliographicData = new JsonObject();
        String text = blockquote.getText();
        // Extract author: The first text before the first comma
        String author = text.split(",")[0].trim();
        bibliographicData.addProperty("author", author);
        // Extract title: Captures text inside quotes
        extractData(text, "\"(.*?)\"", "title", bibliographicData);
        // Extract country: Captures the country after ". En:"
        extractData(text, "\\. En:\\s*([^\\n]+)", "country", bibliographicData);
        // Extract ISSN: Captures the ISSN number after "ISSN:"
        extractData(text, "ISSN:\\s*([\\d-]+)", "ISSN", bibliographicData);
        // Extract editorial: Captures editorial details including volume, issue, pages, and year
        extractData(text, "ed:\\s*([^\\n]+)\\n.*?(v\\.\\d+).*?(fasc\\.\\S+).*?p\\.(\\d+\\s*-\\s*\\d+).*?,(\\d+)", "editorial", bibliographicData);
        // Extract DOI: Captures DOI link if present
        extractData(text, "DOI:\\s*(https?://doi\\.org/|)(\\S+)", "DOI", bibliographicData);
        // Extract key_words: Captures keywords after "Palabras:"
        extractData(text, "Palabras:\\s*([^\n]*)", "key_words", bibliographicData);
        // Extract sectors: Captures sector information after "Sectores:"
        extractData(text, "Sectores:\\s*([^\n]*)", "sectors", bibliographicData);
        // Extract areas: Captures area descriptions after "Areas:"
        extractData(text, "Areas:\\s*([^\n]*)", "areas", bibliographicData);
        SQLiteManager.insertBibliographicElement(connection,bibliographicData,1,autorID, autorFullName);
        return bibliographicData;
    }


    /**
     * Extracts structured bibliographic information from an HTML blockquote element
     * using Selenium WebDriver and stores it in a JsonObject from Gson library.
     * @param blockquote WebDriver instance used to navigate the web page.
     * @return A JsonObject containing structured data extracted from the blockquote.
     */
    public static JsonObject extractBookData(WebElement blockquote,Connection connection,int autorID,String autorFullName) {
        JsonObject bibliographicData = new JsonObject();
        String text = blockquote.getText();
        // Extract author
        String author = text.split(",")[0].trim();
        bibliographicData.addProperty("author", author);
        // Extract title
        extractData(text, "\"(.*?)\"", "title", bibliographicData);
        // Extract country
        extractData(text, "En:\\s*([^\\d\\n]+)", "country", bibliographicData);
        // Extract year
        extractData(text, "En:\\s*[^\\d]*?(\\d{4})", "year", bibliographicData);
        // Extract ISBN
        extractData(text, "ISBN:\\s*([\\d-]+)", "ISBN", bibliographicData);
        // Extract editorial
        extractData(text, "ed:\\s*([^\\s]+(?:\\s[^\\s]+)*)", "editorial", bibliographicData);
        // Extract key_words
        extractData(text, "Palabras:\\s*([^\n]*)", "key_words", bibliographicData);
        // Extract sectors
        extractData(text, "Sectores:\\s*([^\n]*)", "sectors", bibliographicData);
        // Extract areas
        extractData(text, "Areas:\\s*([^\n]*)", "areas", bibliographicData);
        SQLiteManager.insertBibliographicElement(connection,bibliographicData,2,autorID, autorFullName);
        return bibliographicData;
    }
    /**
     * Extracts structured bibliographic information from an HTML blockquote element
     * using Selenium WebDriver and stores it in a JsonObject from Gson library.
     * @param blockquote WebDriver instance used to navigate the web page.
     * @return A JsonObject containing structured data extracted from the blockquote.
     */
    public static JsonObject extractBookChapterData(WebElement blockquote, Connection  connection,int autorID,String autorFullName) {
        JsonObject bibliographicData = new JsonObject();
        String text = blockquote.getText();
        // Extract author
        extractData(text, "Tipo: Otro capítulo de libro publicado\\s*[\\r\\n]+([A-ZÀ-ÿ\\s]+),", "author", bibliographicData);
        // Extract title
        extractData(text, "\"([^\"]+)\"\\s*([^\\.]+)\\.", "title", bibliographicData);
        // Extract country
        extractData(text, "En:\\s*([A-Za-zÀ-ÿ\\s]+)(?=\\s*\\d{4}|\\s*ISBN|$)", "country", bibliographicData);
        // Extract year
        extractData(text, "(\\d{4})(?!.*\\d{4})", "year", bibliographicData);
        // Extract ISBN
        extractData(text, "ISBN:\\s*([\\d-]+)", "ISBN", bibliographicData);
        // Extract editorial
        extractData(text, "ed:\\s*([^\\s]+(?:\\s[^\\s]+)*)", "editorial", bibliographicData);
        // Extract key_words
        extractData(text, "Palabras:\\s*([^\n]*)", "key_words", bibliographicData);
        // Extract sectors
        extractData(text, "Sectores:\\s*([^\n]*)", "sectors", bibliographicData);
        // Extract areas
        extractData(text, "Areas:\\s*([^\n]*)", "areas", bibliographicData);
        SQLiteManager.insertBibliographicElement(connection,bibliographicData,3,autorID,autorFullName);
        return bibliographicData;
    }

    /**
     * Extracts structured bibliographic information from an HTML blockquote element
     * using Selenium WebDriver and stores it in a JsonObject from Gson library.
     * @param blockquote WebDriver instance used to navigate the web page.
     * @return A JsonObject containing structured data extracted from the blockquote.
     */
    public static JsonObject extractScientificNotes(WebElement blockquote,Connection connection,int autorID,String autorFullName) {
        JsonObject bibliographicData = new JsonObject();
        String text = blockquote.getText();
        // Extract author
        extractData(text, "^([A-ZÀ-ÿ\\s,]+)\\s*(?=\")", "author", bibliographicData);
        // Extract title
        extractData(text, ",\\s*\"([^\"]+)\"", "title", bibliographicData);
        // Extract country
        extractData(text, "En:\\s*([A-Za-zÀ-ÿ\\s]+)(?=\\s*\\d{4}|\\s*ISBN|$)", "country", bibliographicData);
        // Extract Publishing Platform
        extractData(text, "\\.\\s*([A-ZÀ-ÿ\\s]+)(?=\\s)", "publishing_platform", bibliographicData);
        // Extract ISNN
        extractData(text, "ISSN:\\s*(\\d{4}-\\d{4})", "ISNN", bibliographicData);
        // Extract editorial
        extractData(text, "ed:\\s*([^\\s]+(?:\\s[^\\s]+)*)", "editorial", bibliographicData);
        // Extract year
        extractData(text, "ed:.*?,(\\d{4})", "year", bibliographicData);
        // Extract key_words
        extractData(text, "Palabras:\\s*([^\n]*)", "key_words", bibliographicData);
        // Extract sectors
        extractData(text, "Sectores:\\s*([^\n]*)", "sectors", bibliographicData);
        // Extract areas
        extractData(text, "Areas:\\s*([^\n]*)", "areas", bibliographicData);
        SQLiteManager.insertBibliographicElement(connection,bibliographicData,4,autorID, autorFullName);
        return bibliographicData;
    }

    /**
     * Extracts structured bibliographic information from an HTML blockquote element
     * using Selenium WebDriver and stores it in a JsonObject from Gson library.
     * @param blockquote WebDriver instance used to navigate the web page.
     * @return A JsonObject containing structured data extracted from the blockquote.
     */
    public static JsonObject extractProject(WebElement blockquote,Connection connection,int autorID,String autorFullName) {
        JsonObject bibliographicData = new JsonObject();
        String text = blockquote.getText();
        // Extract project type
        extractData(text, "Tipo de proyecto:\\s*([^\n]+)", "project_type", bibliographicData);
        // Extract project title
        extractData(text, "(?<=\\r?\\n)([^\\r\\n]+)(?=\\r?\\n)", "title", bibliographicData);
        // Extract project summary
        extractData(text, "(?<=Resumen\\r?\\n)([\\s\\S]+)", "summary ", bibliographicData);
        SQLiteManager.insertBibliographicElement(connection,bibliographicData,5,autorID, autorFullName);
        return bibliographicData;
    }

    /**
     * Extracts data using a provided regex string and stores it in a JsonObject.
     *
     * @param text The text to analyze.
     * @param regex The regex string used for pattern matching.
     * @param propertyName The key to store the extracted value in the JsonObject.
     * @param bibliographicData The JsonObject where extracted data will be stored.
     */
    public static void extractData(String text, String regex, String propertyName, JsonObject bibliographicData) {
        Pattern pattern = Pattern.compile(regex); // Initialize Pattern inside the method
        Matcher matcher = pattern.matcher(text);

        if (matcher.find()) {
            String extractedValue = matcher.group(1).trim();
            bibliographicData.addProperty(propertyName, extractedValue);
        } else {
            bibliographicData.addProperty(propertyName, "[Not specified]");
        }
    }

    /**
     * Extracts the number that appears after the word "de" in the given text.
     * If no valid number is found, the method returns -1.
     *
     * @param text The input string containing the number to extract.
     * @return The extracted number as an integer, or -1 if extraction fails.
     */
    public static double extractNumberRecords(String text) {
        try {
            Pattern pattern = Pattern.compile("de\\s+([\\d,]+)");
            Matcher matcher = pattern.matcher(text);

            if (matcher.find()) {
                String numberFormatted = matcher.group(1).replace(",", "");
                return Double.parseDouble(numberFormatted);
            } else {
                throw new IllegalArgumentException("No valid number found after 'de'.");
            }
        } catch (NumberFormatException e) {
            System.err.println("Error parsing number: " + e.getMessage());
            return -1;
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
            return -1;
        }
    }


}